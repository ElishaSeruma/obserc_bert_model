import json
import os

# Define paths
base_dir = r"C:\Users\elish\Desktop\OBSERC TEST\Dataformatting"
input_path = os.path.join(base_dir, "outputs", "formatted_output.json")
output_path = os.path.join(base_dir, "outputs", "formatted_output_cleaned.json")

# Load JSON
with open(input_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

# Clean 'nan' strings from question and answer fields
def clean_nan_text(text):
    return text.replace("nan", "").replace("NaN", "")

cleaned_data = []
for item in data:
    cleaned_item = {
        "question": clean_nan_text(item["question"]),
        "answer": clean_nan_text(item["answer"])
    }
    cleaned_data.append(cleaned_item)

# Save cleaned output
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(cleaned_data, f, indent=2, ensure_ascii=False)

print(f"✅ Done! Cleaned file saved to: {output_path}")
