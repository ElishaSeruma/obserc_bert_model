import pandas as pd
import json
import os

# Define paths
base_dir = r"C:\Users\elish\Desktop\OBSERC TEST\Dataformatting"
input_path = os.path.join(base_dir, "data", "mentalmanip_detailed.csv")
output_path = os.path.join(base_dir, "outputs", "formatted_output.json")

# Load the original dataset
df = pd.read_csv(input_path)

# Drop unwanted columns
df_cleaned = df.drop(columns=["original movie dialogue", "movie name"], errors="ignore")

# Create the 'question' field
def format_question(row):
    return (
        f"question[Is this dialogue manipulative?]\n"
        f"inner_id: {row['inner_id']}, id: {row['id']}\n"
        f"dialogue: {row['dialogue']}"
    )

# Create the 'answer' field
def format_answer(row):
    parts = [f"answer["]
    parts.append(f"agreement: {row['agreement']}")

    for i in range(1, 4):
        parts.extend([
            f"manipulative_{i}: {row.get(f'manipulative_{i}', '')}",
            f"technique_{i}: {row.get(f'technique_{i}', '')}",
            f"victim_{i}: {row.get(f'victim_{i}', '')}",
            f"vulnerability_{i}: {row.get(f'vulnerability_{i}', '')}",
            f"marks_{i}: {row.get(f'marks_{i}', '')}",
            f"confidence_{i}: {row.get(f'confidence_{i}', '')}"
        ])

    parts.append("]")
    return '\n'.join(parts)

# Apply formatting
records = []
for _, row in df_cleaned.iterrows():
    records.append({
        "question": format_question(row),
        "answer": format_answer(row)
    })

# Save to JSON
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(records, f, indent=2, ensure_ascii=False)

print(f"✅ Done! JSON output saved to: {output_path}")
